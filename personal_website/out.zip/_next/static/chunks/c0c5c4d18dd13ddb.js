__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/958f17876c23bdf7.js",
  "static/chunks/turbopack-42c0dc8f790fbc62.js"
])
